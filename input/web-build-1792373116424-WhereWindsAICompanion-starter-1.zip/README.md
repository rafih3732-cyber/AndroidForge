# Where Winds Meet — Android AI Companion (starter project)

A free, offline-first Android Studio starter project for a Bengali voice companion and optional floating overlay.

## Included
- Bengali speech input using Android `SpeechRecognizer` (device/provider support varies; recognition may use network).
- Bengali text-to-speech via Android `TextToSpeech` (voice availability varies by device).
- A small built-in guide/tips screen.
- Optional floating overlay using Android's `SYSTEM_ALERT_WINDOW` permission.
- No game login, credentials, memory editing, game-file modification, automated taps, or game control.

## Build an APK
1. Install Android Studio (free) on a computer.
2. Open this folder as a project.
3. Allow Gradle to sync. The project uses Android Gradle Plugin 8.6.1 and Kotlin 2.0.21.
4. If prompted, install Android SDK Platform 35.
5. Select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
6. Android Studio shows the APK path after a successful build (typically `app/build/outputs/apk/debug/app-debug.apk`).
7. Copy the APK to your Android phone and install it. Android may ask you to allow installation from that source.

## Enable overlay
Open the app, tap **Enable floating panel**, and grant the Android "Display over other apps" permission. Then tap **Start floating panel**. Android may restrict overlays in some contexts, and some games may hide them.

## Notes
- This starter does not include a cloud AI model. The guide answers common questions with local preset tips, so it is free to run. A genuinely generative AI backend may have free-tier limits or require an API key.
- Speech recognition requires a compatible Android speech recognition service. On-device/offline Bengali recognition is not guaranteed.
- Tested build/runtime status: **not built or device-tested in this environment**.
- The overlay is user-triggered and informational only. It does not inspect or control the game.
