package com.example.wherewindscompanion

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import java.util.Locale

class MainActivity : Activity(), TextToSpeech.OnInitListener {
    private lateinit var tts: TextToSpeech
    private lateinit var answerView: TextView
    private var speechRecognizer: SpeechRecognizer? = null
    private val audioRequest = 410

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this, this)

        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(36, 32, 36, 32)
        }
        val scroller = ScrollView(this)
        val content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroller.addView(content)

        content.addView(TextView(this).apply {
            text = "Where Winds Meet\nবাংলা AI Companion"
            textSize = 25f
        })
        content.addView(TextView(this).apply {
            text = "এটি একটি নিরাপদ সহায়ক: গেম নিয়ন্ত্রণ করে না, অ্যাকাউন্টে লগইন করে না এবং গেমের ফাইল পরিবর্তন করে না।"
            textSize = 16f
            setPadding(0, 20, 0, 20)
        })

        answerView = TextView(this).apply {
            text = "প্রশ্ন করতে নিচের ভয়েস বাটন চাপুন, অথবা টিপস বেছে নিন।"
            textSize = 18f
            setPadding(0, 16, 0, 16)
        }
        content.addView(answerView)
        content.addView(makeButton("🎙 বাংলায় কথা বলুন") { startListening() })
        content.addView(makeButton("⚔️ Combat টিপস") {
            showAnswer("বসের আক্রমণের ধরন আগে লক্ষ্য করুন। আক্রমণ আসার ঠিক আগে dodge করুন, stamina নজরে রাখুন এবং নিরাপদ সময়ে counter-attack দিন।")
        })
        content.addView(makeButton("🧭 Quest টিপস") {
            showAnswer("Quest-এর objective text পড়ুন, map marker মিলিয়ে নিন এবং কোনো objective অস্পষ্ট হলে স্ক্রিনশট নিয়ে প্রশ্ন করুন। এই starter সংস্করণ নিজে স্ক্রিন পড়ে না।")
        })
        content.addView(makeButton("🛡️ নিরাপদ Build টিপস") {
            showAnswer("একটি নির্দিষ্ট playstyle বেছে weapon ও skill synergy দেখুন। upgrade করার আগে resource খরচ এবং build-এর সুবিধা যাচাই করুন।")
        })
        content.addView(makeButton("🪟 Overlay অনুমতি চালু করুন") {
            if (!Settings.canDrawOverlays(this)) {
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            } else {
                showAnswer("Overlay অনুমতি দেওয়া আছে। এবার Start floating panel চাপুন।")
            }
        })
        content.addView(makeButton("▶ Start floating panel") {
            if (!Settings.canDrawOverlays(this)) {
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            } else {
                startService(Intent(this, OverlayService::class.java))
                showAnswer("Floating panel চালু করার অনুরোধ পাঠানো হয়েছে।")
            }
        })
        content.addView(makeButton("■ Stop floating panel") {
            stopService(Intent(this, OverlayService::class.java))
            showAnswer("Floating panel বন্ধ করা হয়েছে।")
        })
        content.addView(makeButton("🔊 উত্তর শুনুন") { speak(answerView.text.toString()) })

        layout.addView(scroller)
        setContentView(layout)
    }

    private fun makeButton(label: String, action: () -> Unit): Button =
        Button(this).apply { text = label; setOnClickListener { action() } }

    private fun startListening() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), audioRequest)
            return
        }
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            showAnswer("এই ফোনে Speech Recognition service পাওয়া যায়নি। Android-এর speech service সেটআপ করে আবার চেষ্টা করুন।")
            return
        }
        speechRecognizer?.destroy()
        speechRecognizer = SpeechRecognizer.createSpeechRecognizer(this)
        speechRecognizer?.setRecognitionListener(object : android.speech.RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) { showAnswer("শুনছি… বাংলায় আপনার প্রশ্ন বলুন।") }
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onError(error: Int) { showAnswer("কথা শনাক্ত করা যায়নি। আবার চেষ্টা করুন বা টিপস বেছে নিন।") }
            override fun onResults(results: Bundle?) {
                val phrase = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty()
                showAnswer(answerFor(phrase))
            }
            override fun onPartialResults(partialResults: Bundle?) {}
            override fun onEvent(eventType: Int, params: Bundle?) {}
        })
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "bn-BD")
            putExtra(RecognizerIntent.EXTRA_PROMPT, "বাংলায় প্রশ্ন বলুন")
        }
        speechRecognizer?.startListening(intent)
    }

    private fun answerFor(question: String): String {
        val q = question.lowercase(Locale.ROOT)
        val response = when {
            q.contains("বস") || q.contains("boss") || q.contains("combat") || q.contains("লড়াই") ->
                "বস ফাইটে আগে attack pattern শিখুন, dodge-এর সময় stamina রাখুন এবং আক্রমণের পরের ফাঁকে counter দিন।"
            q.contains("কোয়েস্ট") || q.contains("quest") || q.contains("মিশন") ->
                "Quest-এর objective পড়ুন, map marker অনুসরণ করুন এবং objective না বুঝলে স্ক্রিনশট নিয়ে জিজ্ঞেস করুন।"
            q.contains("অস্ত্র") || q.contains("weapon") || q.contains("build") ->
                "আপনার পছন্দের playstyle অনুযায়ী weapon ও skill synergy বেছে নিন। Resource খরচের আগে upgrade-এর প্রভাব যাচাই করুন।"
            q.contains("হ্যালো") || q.contains("hello") || q.contains("সালাম") ->
                "হ্যালো! Where Winds Meet-এ কী সাহায্য দরকার? Quest, combat, নাকি build?"
            else -> "আমি এই starter সংস্করণে অফলাইন-ধাঁচের সাধারণ টিপস দিতে পারি। আরও নির্দিষ্ট উত্তর পেতে প্রশ্নে quest, boss, combat, weapon বা build উল্লেখ করুন।"
        }
        return "আপনি বলেছেন: $question\n\n$response"
    }

    private fun showAnswer(text: String) { answerView.text = text }

    private fun speak(text: String) {
        if (::tts.isInitialized) tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "wwm-answer")
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            val result = tts.setLanguage(Locale("bn", "BD"))
            if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
                tts.language = Locale("bn")
            }
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == audioRequest && grantResults.firstOrNull() == PackageManager.PERMISSION_GRANTED) {
            startListening()
        } else if (requestCode == audioRequest) {
            showAnswer("ভয়েস ইনপুটের জন্য microphone permission দরকার। চাইলে টিপস বাটন ব্যবহার করতে পারেন।")
        }
    }

    override fun onDestroy() {
        speechRecognizer?.destroy()
        if (::tts.isInitialized) tts.shutdown()
        super.onDestroy()
    }
}
