package com.example.wherewindscompanion

import android.app.Service
import android.content.Intent
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.view.Gravity
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class OverlayService : Service() {
    private var windowManager: WindowManager? = null
    private var panel: LinearLayout? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (panel != null) return START_NOT_STICKY
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        val view = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(18, 12, 18, 12)
            setBackgroundColor(0xEE202A36.toInt())
        }
        view.addView(TextView(this).apply {
            text = "WWM বাংলা সহায়ক"
            textSize = 16f
            setTextColor(0xFFFFFFFF.toInt())
        })
        view.addView(TextView(this).apply {
            text = "বসের pattern দেখুন • dodge-এর সময় stamina রাখুন • Quest objective পড়ুন"
            textSize = 14f
            setTextColor(0xFFFFFFFF.toInt())
        })
        view.addView(Button(this).apply {
            text = "বন্ধ করুন"
            setOnClickListener { stopSelf() }
        })
        val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else WindowManager.LayoutParams.TYPE_PHONE
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.END
            x = 24
            y = 120
        }
        windowManager?.addView(view, params)
        panel = view
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        panel?.let { view -> try { windowManager?.removeView(view) } catch (_: Exception) {} }
        panel = null
        windowManager = null
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
